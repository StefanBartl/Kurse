window.setTheme = function (th) {
  debugger;
  document.body.classList;
}